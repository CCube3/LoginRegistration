"""
    Routes Configuration File

    Put Routing rules here
"""
from system.core.router import routes
routes['default_controller'] = 'Users'
routes['POST']['/users/create'] = 'Users#create'




routes['POST']['/users/login'] = 'Users#login'



routes['GET']['/success'] = 'Users#success'
